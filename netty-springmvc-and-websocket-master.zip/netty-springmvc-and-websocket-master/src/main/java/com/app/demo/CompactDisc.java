package com.app.demo;
public interface CompactDisc {
    void play();
}