# netty-springmvc-and-websocket
netty based springmvc and websocket
